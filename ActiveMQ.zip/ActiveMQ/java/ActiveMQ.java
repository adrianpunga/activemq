package com.oracle.demo;

import javax.jms.*;
import org.apache.activemq.ActiveMQConnectionFactory;

public class ActiveMQ {
	
	Connection connection = null;
	
	
	public void init(String masterIPport, String slaveIPport, String user, String passwd) throws JMSException  {
		ConnectionFactory factory = new ActiveMQConnectionFactory("failover:(tcp://"+masterIPport+",tcp://"+slaveIPport+")");
        connection = factory.createConnection(user, passwd);
        connection.start();
        System.out.println("<<Connected>>");
        
    }
	
	
	
	public void producer(String queueName, int messageNum) throws JMSException {
		// We create JMS Sessions
		Session sessionA = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
        Queue queue = (Queue) sessionA.createQueue(queueName);

        // We create JMS MessageProducer objects on the sessions
        MessageProducer producer = sessionA.createProducer(queue);

        // We send some messages on each producer
        int numMessages = messageNum;
        
        System.out.println("ProducerA start sending messages");
        
        for (int i = 0; i < numMessages; i++) {
           TextMessage message = sessionA.createTextMessage("This is text message " + i);
           producer.send(message);
           System.out.println("Sent message: " + message.getText());           
        }
        producer.close();
        sessionA.close();
	}

	
	public void consumer(String queueName, int messageNum) throws JMSException {
		
		Session sessionB = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		Queue queue = (Queue) sessionB.createQueue(queueName);
        MessageConsumer consumer = sessionB.createConsumer(queue);
        
        int numMessages = messageNum;
        
    	System.out.println("Consumer start receiving messages");
    	
        for (int i = 0; i < numMessages; i++) {
           TextMessage message = (TextMessage) consumer.receive(2000);
           System.out.println("Got message: " + message.getText());
           
        }
        
        consumer.close();
        sessionB.close();
	}
	
}