package com.oracle.demo;


public class Interface {



    public static void main(String[] args) throws Exception {

        try {

            //Pass param to main method
        	String masterIPport = args[0];
        	String slaveIPport = args[1];
        	String user = args[2];
        	String passwd = args[3];
        	String operation = args[4];
        	String queueName = args[5];
        	String msgNum = args[6];
        	
        	
            System.out.println("<<Starting script>>");      
        
        
            // initialize resources
            ActiveMQ newconn = new ActiveMQ();
            newconn.init(masterIPport, slaveIPport, user, passwd);
            
            
            // Select action
            switch (operation.toLowerCase()) {

            case "consumer":
            	System.out.println(" //CONSUMER\\");
                
                newconn.consumer(queueName, Integer.parseInt(msgNum));
                break; 


            case "producer":
            	System.out.println("//PRODUCER\\ ");
            	
            	newconn.producer(queueName, Integer.parseInt(msgNum));               
                break;
              
                // below is default statement, used when none of the cases is true.
            default:
                System.out.println("None of the following options has been selected: consumer / producer");
            }


            // Release resources
            System.out.println(" ");
            newconn.connection.close();
            System.out.println("Logout");
            
        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}